/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parcial.bevitore;

/**
 *
 * @author debod
 */
public class AlumnoGrado extends Alumno{
    private String carrera;
    private Materia [] materiasG;
    
    public AlumnoGrado(String nom,int dni,String carrera){
       super(nom,dni);
       super.setCantMaterias(30);
       this.materiasG = new Materia [super.getCantMaterias()]; 
//inicialmente el alumno no debe registrar aprobada ninguna materia.esta bien asi?
       this.carrera=carrera;
      
       // inicializo vector materia
       for (int i = 0; i < super.getCantMaterias(); i++) {
               this.materiasG[i]=null;
            }
    }
}
