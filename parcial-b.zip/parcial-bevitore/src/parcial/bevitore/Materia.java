/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parcial.bevitore;

/**
 *
 * @author debod
 */
public class Materia {
    private double nota;
    private String fechaAprob;
    private int codigo;
    
public Materia(double nota, String fecha, int cod){
    this.nota=nota;
    this.fechaAprob=fecha;
    this.codigo=cod;
}

    public double getNota() {
        return nota;
    }

    public void setNota(double nota) {
        this.nota = nota;
    }

    public String getFechaAprob() {
        return fechaAprob;
    }

    public void setFechaAprob(String fechaAprob) {
        this.fechaAprob = fechaAprob;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

}
