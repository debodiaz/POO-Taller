/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parcial.bevitore;

/**
 *
 * @author debod
 */
public class AlumnoDoctorado extends Alumno {
   private String titulo;
   private String uniOrigen;
   private Materia [] materiasD;
   
   public AlumnoDoctorado(String nom,int dni,String tit,String uniO){
       super(nom,dni);
       super.setCantMaterias(8);
       this.materiasD = new Materia [super.getCantMaterias()]; 
       this.titulo=tit;
       this.uniOrigen= uniO;
       // inicializo vector materia
       for (int i = 0; i < super.getCantMaterias(); i++) {
               this.materiasD[i]=null;
            }
       
}
   
   
   
}
