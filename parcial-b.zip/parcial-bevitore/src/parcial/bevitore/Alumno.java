/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parcial.bevitore;

/**
 *
 * @author debod
 */
public abstract class Alumno {
    private String nombre;
    private int DNI;
    private int cantMaterias;

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getDNI() {
        return DNI;
    }

    public void setDNI(int DNI) {
        this.DNI = DNI;
    }

    public int getCantMaterias() {
        return cantMaterias;
    }

    public void setCantMaterias(int cantMaterias) {
        this.cantMaterias = cantMaterias;
    }
    
    
    public Alumno(String nom,int dni){
        this.nombre=nom;
        this.DNI=dni;
        
    }
    
    public void registrarAprobado(double nota, String fecha, int cod){
        
    }
       
    
}
