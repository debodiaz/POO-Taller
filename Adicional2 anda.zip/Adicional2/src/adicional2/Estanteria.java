/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adicional2;

/**
 *
 * @author debod
 */
public class Estanteria {
    private int filas;
    private int columnas;
    private Libro[][] unaEstanteria;

    public Estanteria(int N, int M) {
        this.filas = N;
        this.columnas = M;
        this.unaEstanteria = new Libro[this.filas][this.columnas];
        for (int i = 0; i < this.filas; i++) {
            for (int j = 0; j < this.columnas; j++) {
                this.unaEstanteria[i][j]=null;
            }   
        }
    }
    public Estanteria(){
        this.filas = 5;
        this.columnas = 10;
        this.unaEstanteria = new Libro[this.filas][this.columnas];
        for (int i = 0; i < this.filas; i++) {
            for (int j = 0; j < this.columnas; j++) {
                this.unaEstanteria[i][j]=null;
            }   
        }
    }

    public int getFilas() {
        return filas;
    }

   

    public int getColumnas() {
        return columnas;
    }

 
    
    public void almacenarLibro(Libro unLibro,int nroF,int nroC){//fila y columna validos
        this.unaEstanteria[nroF][nroC]=unLibro;
    }
    /* sacarLibro: recibe el t�tulo de un libro, y saca y devuelve el libro con ese t�tulo, quedando su lugar
    disponible. Tenga en cuenta que el libro puede no existir.*/

    public Libro sacarLibro(String titulo){
        int f=0;
        int c=0;
        Libro aux=null;
        boolean encontre=false;
        while ((f <this.filas) && (!encontre)){
            while((c<this.columnas)&&(!encontre)){
                 if (this.unaEstanteria[f][c]!=null){
                if(this.unaEstanteria[f][c].getTitulo().equals(titulo)){
                    encontre=true;
                    /*aux.setTitulo(this.unaEstanteria[f][c].getTitulo());
                    aux.setPeso(this.unaEstanteria[f][c].getPeso());
                    aux.setCantidadPaginas(this.unaEstanteria[f][c].getCantidadPaginas());
                    aux.setUnAutor(unaEstanteria[f][c].getUnAutor().getNombre(),unaEstanteria[f][c].getUnAutor().getBiografia());*///?? COMO ASIGNARLE A UN OBJETO OTRO OBJETO?
                    aux = unaEstanteria[f][c];
                    unaEstanteria[f][c]=null; // solo en la posicion del vector se pone null, el libro sigue ahi guardado
                }
                 }
                
                    c++;
                    
            }
            f++;
            c=0;
        }
        
        
        return aux;
                
            
    }
    
    public Libro calcularLibroMasGrande(){
       //NUNCA INICIALIZAR UN OBJ AUXILIAR EN NULL SI ME P�NTA USAR SETTERS
       
        int max=-1;
        int posF=-1;//tienen q inicializarse en posicion invalida
        int posC=-1;
        
        for (int i = 0; i < this.filas; i++) {
            for (int j = 0; j < this.columnas; j++) {
                if (this.unaEstanteria[i][j]!=null){
                if(this.unaEstanteria[i][j].getCantidadPaginas()>max){
                    max=this.unaEstanteria[i][j].getCantidadPaginas();
                    posF=i;
                    posC=j;
                }
            } 
        }
        }
        
            /*aux.setTitulo(this.unaEstanteria[posF][posC].getTitulo());
            aux.setPeso(this.unaEstanteria[posF][posC].getPeso());
            aux.setCantidadPaginas(this.unaEstanteria[posF][posC].getCantidadPaginas());
            aux.setUnAutor(unaEstanteria[posF][posC].getUnAutor().getNombre(),unaEstanteria[posF][posC].getUnAutor().getBiografia()); */  
        
        
        
        return this.unaEstanteria[posF][posC];
                
    }
    
    public int calcularEstanteMasPesado(){
        double max=-1;
        int fila=0;
        double suma;
        
        for (int i = 0; i < this.filas; i++) {
            suma=0;
            for (int j = 0; j < this.columnas; j++) {
                if (this.unaEstanteria[i][j]!=null){
                suma+= this.unaEstanteria[i][j].getPeso();
                
                  
                }
                if (suma>max){
                    max=suma;
                    fila=i;
            } 
        }
        }
        return fila;
    }
}
