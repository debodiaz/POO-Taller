/*
 Ejercicio 2. Queremos representar estanterÃ­as de libros. Una estanterÃ­a mantiene sus libros
organizados en N estantes cada uno con lugar para M libros. Un libro posee tÃ­tulo, peso, cantidad de
pÃ¡ginas y su autor (del que se registra nombre y biografÃ­a).
a) Implemente las clases de su modelo, con sus atributos y getters/setters adecuados.
b) Provea constructores para iniciar autores y los libros a partir de toda su informaciÃ³n.
c) Provea un constructor para iniciar la estanterÃ­a para N estantes y lugar para M libros por estante
(inicialmente no debe tener libros cargados).
d) Provea un constructor para iniciar la estanterÃ­a para 5 estantes y lugar para 10 libros por estante
(inicialmente no debe tener libros cargados).
e) Implemente los siguientes mÃ©todos:
- almacenarLibro: recibe un libro, un nro. de estante y nro. de lugar vÃ¡lidos y guarda al libro en la
estanterÃ­a. Asuma que dicho lugar estÃ¡ disponible.
- sacarLibro: recibe el tÃ­tulo de un libro, y saca y devuelve el libro con ese tÃ­tulo, quedando su lugar
disponible. Tenga en cuenta que el libro puede no existir.
- calcularLibroMasGrande: calcula y devuelve el libro con mÃ¡s pÃ¡ginas de la estanterÃ­a.
- calcularEstanteMasPesado: calcula y devuelve el nÃºmero del estante mÃ¡s pesado (teniendo en
cuenta el peso de sus libros).
d) Realice un programa que instancie una estanterÃ­a para 5 estantes y 3 libros por estante. Almacene
7 libros en la estanterÃ­a. A partir de la estanterÃ­a: saque el libro â€œ2001 Odisea del Espacioâ€� e informe
su representaciÃ³n String; luego, informe
- el tÃ­tulo del libro mÃ¡s grande
- el nÃºmero del estante mÃ¡s pesado.
 */
package adicional2;
import PaqueteLectura.Lector;

/**
 *
 * @author debod
 */
public class Adicional2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      Estanteria unaEst = new Estanteria(5,3);
        for (int i = 0; i < 1; i++) {
			
		
           System.out.println("Ingresemos los datos del autor");
            Autor unAut =new Autor(Lector.leerString(),Lector.leerString());
            System.out.println("Ingresemos los del libro");
            Libro unLibro =new Libro(Lector.leerString(),Lector.leerDouble(),Lector.leerInt(),unAut);
            System.out.println("Ingresa fila y columna");
            unaEst.almacenarLibro(unLibro,Lector.leerInt(),Lector.leerInt());
            /*Libro unLibro1 =new Libro(Lector.leerString(),Lector.leerDouble(),Lector.leerInt());
            unaEst.almacenarLibro(unLibro1,Lector.leerInt(),Lector.leerInt());*/
        }
        System.out.println("dsfasdf");
        if(unaEst.sacarLibro("2001 Odisea del Espacio")!= null) {//NO SE IMPRIME ALGO Q ES NULL!!!!
        System.out.println(unaEst.sacarLibro("2001 Odisea del Espacio").toString());
        }
        System.out.println(unaEst.calcularLibroMasGrande().getTitulo());
        System.out.println(unaEst.calcularEstanteMasPesado());
        
        
        
      
      
    }
    
}
