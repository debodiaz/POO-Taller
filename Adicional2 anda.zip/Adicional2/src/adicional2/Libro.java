/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adicional2;

/**
 *
 * @author debod
 */
public class Libro {
    private String titulo;
    private double peso;
    private int cantidadPaginas;
    private Autor unAutor;
    
    public Libro(String unTit,double unPeso,int cantP,Autor unAut){
        this.titulo=unTit;
        this.peso=unPeso;
        this.cantidadPaginas=cantP;
        this.unAutor= unAut;
    }
    
    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public int getCantidadPaginas() {
        return cantidadPaginas;
    }

    public void setCantidadPaginas(int cantidadPaginas) {
        this.cantidadPaginas = cantidadPaginas;
    }

    public Autor getUnAutor() {
        return unAutor;
    }

    public void setUnAutor(String nombre, String bio) {
        this.unAutor.setNombre(nombre); 
        this.unAutor.setBiografia(bio);
    }
    
    public String toString(){
        return "El titulo "+this.titulo+", el peso "+this.peso+" , la cantidad d epags "+this.cantidadPaginas+" y el autor es "+this.unAutor.getNombre();
    }
    
}
