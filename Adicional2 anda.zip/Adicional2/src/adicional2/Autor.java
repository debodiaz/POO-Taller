/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adicional2;

/**
 *
 * @author debod
 */
public class Autor {
    private String nombre;
    private String biografia;
    
    public Autor(){
        
    }
    public Autor(String unNombre,String bio){
        this.nombre=unNombre;
        this.biografia=bio;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getBiografia() {
        return biografia;
    }

    public void setBiografia(String biografia) {
        this.biografia = biografia;
    }
    
    
    
}
