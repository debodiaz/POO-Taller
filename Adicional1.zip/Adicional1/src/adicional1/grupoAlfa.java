/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adicional1;

/**
 *
 * @author debod
 */
public class grupoAlfa extends Grupo {
    /*Aplicar una dosis D (double) d
    en el Grupo Alfa se le aplica la dosis D a todos los pacientes*/
    public grupoAlfa(){
        super();
    }
    @Override
    public void aplicarDosis(double D){
        for (int i = 0; i < super.getDimL(); i++) {
            super.setUnGrupoDosis(D, i);
            
        }
    }

 

    
}
