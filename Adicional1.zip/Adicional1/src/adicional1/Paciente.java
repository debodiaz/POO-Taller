/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adicional1;

import PaqueteLectura.GeneradorAleatorio;

/**
 *
 * @author debod
 */
public class Paciente {
    private int id;//es necesario esto?
    private String nombre;
    private double ultResGlucosa;
    private double ultDosis;

    public Paciente(int id, String nombre, double ultResGlucosa, double ultDosis) {
        this.id = id;
        this.nombre = nombre;
        this.ultResGlucosa = ultResGlucosa;
        this.ultDosis = ultDosis;
    }
    

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getUltResGlucosa() {
        return ultResGlucosa;
    }

    public void setUltResGlucosa(double ultResGlucosa) {
        this.ultResGlucosa = ultResGlucosa;
    }

    public double getUltDosis() {
        return ultDosis;
    }

    public void setUltDosis(double ultDosis) {
        this.ultDosis = ultDosis;
    }
    public void aplicarDosis(double D){
 
               this.ultDosis= D;
               double aux =this.ultResGlucosa;
               int a= (int)aux;
               System.out.println(aux);
               this.ultResGlucosa= (aux - GeneradorAleatorio.generarDouble(1));
        System.out.println(this.ultResGlucosa);//generar aleatorio solo recibe int, asiq uso la parte entera de aux, pero a veces aux da 0.1 y su parte entera de 0 y el generador verga no me deja hay otra forma ??
        }
    public String toString(){
        return "el id es "+this.id+", el nombre es "+this.nombre+", el ultimo resultado de glucosa es "+this.ultResGlucosa+" y la ultima dosis es de "+this.ultDosis;
    }
            
    }

