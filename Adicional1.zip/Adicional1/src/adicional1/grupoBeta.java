/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adicional1;

/**
 *
 * @author debod
 */
public class grupoBeta extends Grupo {
    grupoBeta(){
        super();
    }
   @Override
   public void aplicarDosis(double D){
       /*en el Grupo Beta se
le aplica la dosis D a los pacientes cuya glucosa supera el valor 2.5.*/
       for (int i = 0; i <super.getDimL(); i++) {
          if(super.getUnGrupo(i).getUltResGlucosa()>2.5){
              super.setUnGrupoDosis(D,i);
          }
           
       }
   } 
}
