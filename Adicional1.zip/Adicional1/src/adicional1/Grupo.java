/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adicional1;

/**
 *
 * @author debod
 */
public abstract class Grupo {
    private Paciente[] unGrupo;
    private int dimF;
    private int dimL;

    public int getDimF() {
        return dimF;
    }

    

    public int getDimL() {
        return dimL;
    }

    

    public Grupo() {
        this.dimF=10;
        this.unGrupo = new Paciente[this.dimF];
        for (int i = 0; i < this.dimF; i++) {
             unGrupo[i]=null;
            
        }
        this.dimL=0;
    }
    public int agregarPaciente(Paciente p){
     this.unGrupo[this.dimL] = p;
     this.dimL++;
     return this.unGrupo[this.dimL-1].getId();
             
    }
    public Paciente obtenerPaciente(int ID){
        ID= ID-1;
        return this.unGrupo[ID];
    }
    public Paciente getUnGrupo(int i){
        return this.unGrupo[i];
    }
    public void setUnGrupoDosis(double D,int i){
        this.unGrupo[i].aplicarDosis(D);
    }
    
    public abstract void aplicarDosis(double D);
    public String toStringGrupo(){
        String aux="";
        for (int i = 0; i < this.getDimL(); i++) {
            aux=i+""+unGrupo[i].toString()+"";
            
        }
        return aux;
    }
}

