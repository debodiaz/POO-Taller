/*
 Un Laboratorio realiza experimentos para evaluar la eficacia de un nuevo fármaco para
la diabetes y para ello conformó dos grupos de pacientes: Grupo Alfa y Grupo Beta.
Ambos grupos registran la información de a lo sumo 10 pacientes (identificados de 1 a 10). De cada
paciente se guarda: nombre, último resultado de glucosa (double) y última dosis recibida de fármaco
(double). Sin embargo, los grupos difieren en la forma de aplicar el fármaco a los pacientes (esto se
detalla más adelante)
1) Genere las clases necesarias, cada una con los constructores, estado, getters y setters
adecuados. Tenga en cuenta que los grupos inicialmente no tienen pacientes.
2) Agregue a la clases que corresponda los métodos necesarios para:
a) Agregar un paciente P al grupo y retornar su número identificatorio en el grupo (ID).
b) Obtener un paciente del grupo dado un ID válido (1 a 10).
c) Aplicar una dosis a un paciente. Se recibe una dosis D (double) y se debe modificar su
última dosis recibida a D y disminuir la glucosa en un valor aleatorio entre 0 y 1.
d) Aplicar una dosis D (double) de fármaco a los pacientes del grupo, teniendo en cuenta
que: en el Grupo Alfa se le aplica la dosis D a todos los pacientes; en el Grupo Beta se
le aplica la dosis D a los pacientes cuya glucosa supera el valor 2.5.
e) Obtener la representación string del grupo, la cual se compone por el ID,. nombre,
última glucosa y última dosis de todos los pacientes del grupo
3) Realice un programa que instancie un Grupo Alfa y un Grupo Beta. Llene cada grupo con
pacientes (el primero con 3 y el segundo con 4). Aplique una dosis D de fármaco (leída por
teclado) a los pacientes de cada grupo. Imprima la representación string de cada grupo.

 */
package adicional1;
import PaqueteLectura.GeneradorAleatorio;
import PaqueteLectura.Lector;
/**
 *
 * @author debod
 */
public class Adicional1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        grupoAlfa grupoA=new grupoAlfa();
        grupoBeta grupoB=new grupoBeta();
        for (int i = 0; i < 3; i++) {
            Paciente p=new Paciente(GeneradorAleatorio.generarInt(10), GeneradorAleatorio.generarString(30), GeneradorAleatorio.generarDouble(5),  GeneradorAleatorio.generarDouble(5));
            grupoA.agregarPaciente(p);
            
        }
         for (int i = 0; i < 4; i++) {
            Paciente p=new Paciente(GeneradorAleatorio.generarInt(10), GeneradorAleatorio.generarString(30), GeneradorAleatorio.generarDouble(5),  GeneradorAleatorio.generarDouble(5));
            grupoB.agregarPaciente(p);
            
        }
         System.out.println("Ingrese una dosis a aplicar ");
         double D=Lector.leerDouble();
         grupoA.aplicarDosis(D);
         grupoB.aplicarDosis(D);
         grupoA.toStringGrupo();
         grupoB.toStringGrupo();
    }
    
}
