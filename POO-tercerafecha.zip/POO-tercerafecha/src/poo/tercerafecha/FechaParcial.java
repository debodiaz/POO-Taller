/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo.tercerafecha;

/**
 *
 * @author debod
 */
public class FechaParcial {
    private int cantSalas;
    private Sala[] unaFecha;

    public int getCantSalas() {
        return cantSalas;
    }

    public FechaParcial(int N,int M) {
        this.cantSalas = N;
        unaFecha = new Sala[this.cantSalas];
        //iniciar las fechas para N salas esta bien asi??:
        for (int i = 0; i < this.cantSalas; i++) {
            Sala salita = new Sala(M);
            unaFecha[i]=salita;
        }
    }

    public void agregarAlumnoSala(Alumno mengano,int X){//asuma que X es valido y que hay lugar
        
             unaFecha[X].agregarAlumno(mengano);
            
        
    }
    public void asignarTema(){
        for (int i = 0; i < this.cantSalas; i++) {
            unaFecha[i].asignarTemaSala();
            
        }
    }
    public String toString(int T){
        String aux="";
        for (int i = 0; i < this.cantSalas; i++) {
            aux+=unaFecha[i].toStringSala(T);
            
        }
        return aux;
    }
    
    
}
