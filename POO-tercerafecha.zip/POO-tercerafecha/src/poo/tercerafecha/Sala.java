/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo.tercerafecha;
import PaqueteLectura.GeneradorAleatorio;
/**
 *
 * @author debod
 */
public class Sala {
    private int dimF;
    private int dimL;
    private Alumno[] unaSala;

    public int getDimF() {
        return dimF;
    }

  

    public int getDimL() {
        return dimL;
    }

   

    public Sala(int M) {
        this.dimF = M;
        this.dimL=0;
        unaSala= new Alumno[dimF];
        for (int i = 0; i < this.dimF; i++) {
            unaSala[i]=null;
            
        }
        
    }
    public void agregarAlumno(Alumno fulano){
        
            unaSala[this.dimL]=fulano;
            this.dimL++;
            
        }
        
    public void asignarTemaSala(){
        for (int i = 0; i < this.dimL; i++) {
           unaSala[i].setnTema(GeneradorAleatorio.generarInt(this.dimF));
            
        }
    }
    public String toStringSala(int T){
        String aux="";
        for (int i = 0; i < this.dimL; i++) {
            if(unaSala[i].getnTema()== T ){
            aux+= unaSala[i].toString();
            }
        }
        return aux;
    }
   
}
