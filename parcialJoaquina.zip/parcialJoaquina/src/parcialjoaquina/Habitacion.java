/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parcialjoaquina;

/**
 *
 * @author debod
 */
public class Habitacion {
    private double costoxDía;
    private boolean ocupada;
    private Cliente unCliente; 
    private int nPiso;
    

    public Habitacion( int n) {
        
        this.nPiso=n;
        
        this.costoxDía = 800+ (100* this.nPiso);
        this.ocupada =false;
        
        
    }

    public int getnPiso() {
        return nPiso;
    }

    public void setnPiso(int nPiso) {
        this.nPiso = nPiso;
    }

   

    public double getCostoxDía() {
        return costoxDía;
    }

    public void setCostoxDía(double costoxDía) {
        this.costoxDía = costoxDía;
    }

    public boolean isOcupada() {
        return ocupada;
    }

    public void setOcupada(boolean ocupada) {
        this.ocupada = ocupada;
    }

    public Cliente getUnCliente() {
        return unCliente;
    }

    public void setUnCliente(Cliente unCliente) {
        this.unCliente = unCliente;
    }
}
