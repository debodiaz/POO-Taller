/*
 Realice un sistema para gestionar habitaciones de un hotel. El hotel tiene N pisos y M habitaciones por piso. 
El sistema debe mantener en una estructura adecuada los datos de las habitaciones: costo por día, si está ocupada y, 
en ese caso, los datos del cliente que la ocupa (nombre y DNI). 
Genere las clases necesarias. Provea constructores para iniciar el sistema para N pisos y M habitaciones por piso, 
con cada habitación desocupada y con costo de 800 + 100*nro_de_piso_de_la_habitación.
2-   Implemente los métodos necesarios, en las clases que corresponda, que permitan: 
Dado un cliente y un nro. de piso X, ingresarlo en la primera habitación desocupada del piso X. 
Retornar el nro. de habitación asignada. Asuma que hay una habitación desocupada en el piso y que X es válido. 
Dado un nro. de habitación Y, liberar todas las habitaciones nro. Y ocupadas (de todos los pisos). 
Retornar un String con los nombres de los clientes a los que se debe cobrar. Asuma que Y es válido.

3- Realice un programa que instancie el sistema para 4 pisos y 2 habitaciones por piso. Ingrese clientes al sistema. 
Para finalizar, imprima el resultado del inciso 2. b. 

 */
package parcialjoaquina;
import PaqueteLectura.GeneradorAleatorio;
import PaqueteLectura.Lector;
/**
 *
 * @author debod
 */
public class ParcialJoaquina {

    /**
     * Realice un programa que instancie el sistema para 4 pisos 
     * y 2 habitaciones por piso. Ingrese clientes al sistema. 
     * Para finalizar, imprima el resultado del inciso 2. b. 
     */
    public static void main(String[] args) {
       Hotel unHotel=new Hotel(4,2);
        for (int i = 0; i < 3; i++) {
            Cliente mengano = new Cliente(GeneradorAleatorio.generarInt(100),GeneradorAleatorio.generarString(50));
            unHotel.ingresarCliente(mengano, Lector.leerInt());
            System.out.println("Cliente ingresado");
        }
        System.out.println(unHotel.liberarHabitacion(Lector.leerInt()));
    }
    
}
