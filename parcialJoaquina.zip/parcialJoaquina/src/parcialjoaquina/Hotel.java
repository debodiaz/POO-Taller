/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parcialjoaquina;

/**
 *
 * @author debod
 */
public class Hotel {
    private int pisos;
    private int habitacionesxPiso;
    private Habitacion[][] unHotel;

    public Hotel(int N, int M) {
        this.pisos = N;
        this.habitacionesxPiso = M;
        unHotel = new Habitacion[this.pisos][this.habitacionesxPiso];
        for (int i = 0; i < this.pisos; i++) {
            for (int j = 0; j < this.habitacionesxPiso; j++) {
                Habitacion unaHab=new Habitacion(i);
                unHotel[i][j]= unaHab;
               
                //esta bien????
                
            }
            
        }
    }

    public int getPisos() {
        return pisos;
    }

    public void setPisos(int pisos) {
        this.pisos = pisos;
    }

    public int getHabitacionesxPiso() {
        return habitacionesxPiso;
    }

    public void setHabitacionesxPiso(int habitacionesxPiso) {
        this.habitacionesxPiso = habitacionesxPiso;
    }
  /*Dado un cliente y un nro. de piso X, 
    ingresarlo en la primera habitación desocupada del piso X. 
    Retornar el nro. de habitación asignada. 
    Asuma que hay una habitación desocupada en el piso y que X es válido. */
    public int ingresarCliente(Cliente unCli, int nroPiso){
        int i=0;
        while((i<this.habitacionesxPiso)&&(unHotel[nroPiso][i].isOcupada()!=false)){
            i++;
        }
        if (i<this.habitacionesxPiso){
            unHotel[nroPiso][i].setUnCliente(unCli);//esta bien o deberia preguntar por isOcupada?
            unHotel[nroPiso][i].setOcupada(true);
            unHotel[nroPiso][i].setCostoxDía(nroPiso);
            unHotel[nroPiso][i].setCostoxDía(nroPiso);
            
             
        }
        return i;
    }
 /*Dado un nro. de habitación Y, liberar todas las habitaciones nro. Y ocupadas 
    (de todos los pisos). Retornar un String con los nombres de los clientes
    a los que se debe cobrar. Asuma que Y es válido.*/
    
    public String liberarHabitacion(int Y){//asumo q Y e svalido
        String aux="";
        for (int i = 0; i < this.pisos; i++) {
            if (unHotel[i][Y].isOcupada() == true){
            unHotel[i][Y].setOcupada(false);
            aux+=unHotel[i][Y].getUnCliente().getNombre();
            unHotel[i][Y].setUnCliente(null);//esta bien???
            
        }
        }
        return aux;
    }
}
