/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parcialtercerafecha;

/**
 *
 * @author debod
 */
public class Alumno {
    private String nombre;
    private int dni;
    private int nroTema;
    
    public Alumno(String nom, int dni){
        this.nombre= nom;
        this.dni= dni;
        this.nroTema= -1;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getDni() {
        return dni;
    }

    public void setDni(int dni) {
        this.dni = dni;
    }

    public int getNroTema() {
        return nroTema;
    }

    public void setNroTema(int nroTema) {
        this.nroTema = nroTema;
    }
    
    public String toString(){
        return "El nombre del alumno es "+this.nombre+" y su dni es "+this.dni;
    }
    
}
