/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parcialtercerafecha;

import PaqueteLectura.GeneradorAleatorio;

/**
 *
 * @author debod
 */
public class fechaParcial {
    private int cantSalas;
    private Alumno [][] salas;
    private int[] dimL;
    private int cantAlumnos;//ESTA BIEN HACER GETTERS Y SETTERS DE LAS DIMENSIONES FISICAS CANTSALAS Y CANTALUMNOS?
   
    
   public fechaParcial(int N, int M){
       this.cantSalas=N;
       this.cantAlumnos= M;
       salas = new Alumno[this.cantSalas][this.cantAlumnos];
       dimL= new int[this.cantSalas];
       
       for (int j = 0; j <this.cantSalas; j++) {
          dimL[j]=0;
           
       }
       
       for (int i = 0; i < this.cantSalas; i++) {
           for (int j = 0; j < this.cantAlumnos; j++) {
               this.salas[i][j]=null;
           }
       }
   } 
 
    public int getCantSalas() {
        return cantSalas;
    }

    public void setCantSalas(int cantSalas) {
        this.cantSalas = cantSalas;
    }

    public int getCantAlumnos() {
        return cantAlumnos;
    }

    public void setCantAlumnos(int cantAlumnos) {
        this.cantAlumnos = cantAlumnos;
    }
   public void agregarAlumno(Alumno unAlumno, int X){//ESTA BIEN?o hay q hacer tantas dimensiones logicas como salas haya?????
 
//Agregar un alumno a la sala X de la fecha. Asuma que X es válido y que hay lugar para el alumno.
     
       this.salas[X-1][this.dimL[X-1]]= unAlumno;
       this.dimL[X-1]++;
   }
   
   public void asignarTema(){//esta bien???
       
/*Asignar un tema a todos los alumnos de la fecha, de la siguiente manera: a los alumnos de una misma
   sala se le asignan temas al azar (entre 1 y M).*/
       for (int i = 0; i < this.cantSalas; i++) {
           for (int j = 0; j < this.dimL[i]; j++) {
              this.salas[i][j].setNroTema(GeneradorAleatorio.generarInt(this.cantAlumnos));
           }
       } 
   }
   public String toStringV(int T){
       //Obtener un String con la información de los alumnos (nombre, DNI) que rinden el tema T.
       String aux="";
       for (int i = 0; i < this.cantSalas; i++) {
           for (int j = 0; j < this.dimL[i]; j++) {
               if(salas[i][j].getNroTema() == T ){
                   aux+= salas[i][j].toString();
               } 
           }  
       }
       return aux;
   }
   
   
}
